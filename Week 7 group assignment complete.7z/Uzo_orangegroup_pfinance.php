<!DOCTYPE html>
<html>
<head>
<title> List of all the mobile devices </title>
<meta charset="utf-8" />
<link href="ora_css.css" type="text/css" rel="stylesheet" />
</head>
<body>
    <p>
<h2>Personal Finance Customers Information</h2>
</p>
<?php
 $dsn ='mysql:host=laureatestudentserver.com;dbname=laureate_IN169';
 $username = 'laureate_IN169';
 $password = 'tUv5EKnV9KaK';
 $dbc = new PDO($dsn, $username, $password);
 $query = 'SELECT * FROM uzoorangeorabanks ORDER BY AcctNo';
 $results = $dbc->query($query);
 $rows = $results->rowCount();
 ?>
<table>
<caption>Personal Finance Customer Database</caption>
<thead>
<tr>
<th>AcctNo</th>
<th>Name</th>
<th>DofB</th>
<th>Address</th>
<th>Email</th>
<th>Sex</th>
<th>MartialStatus</th>
<th>Documents</th>
<th>ProofofIdent</th>
</tr>
</thead>
<?php
if ($rows == 0)
{
echo("<p> There are no values returned</p>");
echo("<p><a href='personal_finance.html'>You may Proceed</a></p>");
}
else {
foreach ($results as $selectedFinanceInfo) :
    ?>
<tr>
<td class = "left">
<?php echo $selectedFinanceInfo['AcctNo']; ?>
</td>
<td class = "left">
<?php echo $selectedFinanceInfo['Name']; ?>
</td>
<td class = "left">
<?php echo $selectedFinanceInfo['DofB']; ?>
</td>
<td class = "left">
<?php echo $selectedFinanceInfo['Address']; ?>
</td>
<td class = "left">
<?php echo $selectedFinanceInfo['Email']; ?>
</td>
<td class = "left">
<?php echo $selectedFinanceInfo['Sex']; ?>
</td>
<td class = "left">
<?php echo $selectedFinanceInfo['MartialStatus']; ?>
</td>
<td class = "left">
<?php echo $selectedFinanceInfo['Documents']; ?>
</td>
<td class = "left">
<?php echo $selectedFinanceInfo['ProofofIdent']; ?>
</td>
</tr>
<?php endforeach;
echo("<p><a href='personal_finance.html'>Proceed</a></p>");
}
$dbc = null;
?>
</table>
</body>
</html>

