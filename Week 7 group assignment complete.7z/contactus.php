<!DOCTYPE html>
<html>
<head>
    <title> List of all the mobile devices </title>
    <meta charset="utf-8" />
    <link href="ora_css.css" type="text/css" rel="stylesheet" />
</head>
<body>
<?php
 if ( ! empty( $_POST ) ) {
 //Connecting to the database
 $mysqli = new mysqli( 'laureatestudentserver.com', 'laureate_IN169', 'tUv5EKnV9KaK', 'laureate_IN169' );
 //To check if it is connected or not
if ( $mysqli->connect_error ) {
    die( 'Connect Error: ' . $mysqli->connect_errno . ': ' . $mysqli->connect_error );
  }
  $feedback=implode(',', $_POST['feedback']);
  $SiteQuality=implode(',', $_POST['SiteQuality']);
 //After which we insert values into the database
//Then we will run the add or insert query.
$sql = "INSERT INTO uzoorangeoracontactus ( AcctNumber, fullName, Email, Feedback, Details, Replyconf ) VALUES ( '{$mysqli->real_escape_string($_POST['fullaccountnumber'])}', '{$mysqli->real_escape_string($_POST['fullcontactname'])}', '{$mysqli->real_escape_string($_POST['fullemail'])}', '{$mysqli->real_escape_string($feedback)}', '{$mysqli->real_escape_string($_POST['feedbackproblem'])}', '{$mysqli->real_escape_string($SiteQuality)}')";
  $insert = $mysqli->query($sql);
  // Print response from MySQL
  if ( $insert ) {
    echo "Success,Information on your application form has been submitted! Row ID: {$mysqli->insert_id}";
    echo("<p><a href='Uzo_orangegroup_contactus.php'>Proceed</a></p>");
  } else {
    die("Error: {$mysqli->errno} : {$mysqli->error}");
  }
  // Connection will then be closed
  $mysqli->close();
}
?>
</body>
</html>