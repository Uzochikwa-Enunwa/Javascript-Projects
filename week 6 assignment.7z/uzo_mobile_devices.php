<!DOCTYPE html>
<html>
<head>
<title> List of all the mobile devices </title>
<meta charset="utf-8" />
<link href="phoneandtabletDevices.css" type="text/css" rel="stylesheet" />
</head>
<body>
    <p>
<h2>List of Mobile Devices and Tablets in Orange group Database</h2>
</p>
<?php
 $dsn =
'mysql:host=uzochikwa-TOSH;dbname=uzomobiledevices';
 $username = 'root';
 $password = 'AnAkin@123';
 $dbc = new PDO($dsn, $username, $password);
 $query = 'SELECT * FROM uzoorangedevices ORDER BY refNo';
 $results = $dbc->query($query);
 $rows = $results->rowCount();
 ?>
<table>
<caption>Mobiles in Stock</caption>
<thead>
<tr>
<th>refNo</th>
<th>name</th>
<th>DeviceType</th>
<th>Colour</th>
<th>StockLevel</th>
<th>SalesThisMonth</th>
<th>CustomerRating(1-5)</th>
</tr>
</thead>
<?php
if ($rows == 0)
{
echo("<p> There are no values returned</p>");
echo("<p><a href='mainpage.html'>You may Proceed</a></p>");
}
else {
foreach ($results as $uzodevices) :
    ?>
<tr>
<td class = "left">
<?php echo $uzodevices['refNo']; ?>
</td>
<td class = "left">
<?php echo $uzodevices['name']; ?>
</td>
<td class = "left">
<?php echo $uzodevices['DeviceType']; ?>
</td>
<td class = "left">
<?php echo $uzodevices['Colour']; ?>
</td>
<td class = "left">
<?php echo $uzodevices['StockLevel']; ?>
</td>
<td class = "left">
<?php echo $uzodevices['SalesThisMonth']; ?>
</td>
<td class = "left">
<?php echo $uzodevices['CustomerRating(1-5)']; ?>
</td>
</tr>
<?php endforeach;
}
$dbc = null;
?>
</table>
<?php echo("<p><a href='mainpage.html'>You may Proceed</a></p>"); ?>
</body>
</html>





