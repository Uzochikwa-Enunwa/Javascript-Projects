<!DOCTYPE html>
<html>
<head>
<title> Searching for a Single Record </title>
<meta charset="utf-8" />
<link href="ora_css.css" type="text/css" rel="stylesheet" />
</head>
<body>

<p>
<h2>Personal Finance Customer Information Search Result</h2>
<?php
$AcctNumber = $_POST['AcctNumber']; 
$dsn = 'mysql:host=laureatestudentserver.com;dbname=laureate_IN169';
$username = 'laureate_IN169';
$password = 'tUv5EKnV9KaK';
$dbc = new PDO($dsn, $username, $password);
$query = "SELECT * FROM uzoorangeoracontactus WHERE AcctNumber ='" . $AcctNumber . "'";
/* The SQL says "Select everything from the uzoorangeoracontactus table where the account number equals that which the user typed into the previous HTML form. As the AcctNumber is unique, there will be at most one record */
$results = $dbc->query($query); 
$rows = $results->rowCount(); ?>  
<?php 
if ($rows == 0) {
      echo("<p> There is no information to show because the account does not exist");
}
else {
$selectedcontactus = $results->fetch();
/* Fetch a record from the $results variable and store it in $selectedFinanceInfo. There will be a maximum of one record */      
?>
<table border>
<caption>Personal finance customer Query </caption>
<thead>
<tr>
<th>AcctNumber</th>
<th>fullName</th>
<th>Email</th>
<th>Feedback</th>
<th>Details</th>
<th>Replyconf</th>
</tr>
</thead> 
<tr>
<td class = "left">
<?php echo $selectedcontactus['AcctNumber']; ?>
</td>
<td class = "left">
<?php echo $selectedcontactus['fullName']; ?>
</td>
<td class = "left">
<?php echo $selectedcontactus['Email']; ?>
</td>
<td class = "left">
<?php echo $selectedcontactus['Feedback']; ?>
</td>
<td class = "left">
<?php echo $selectedcontactus['Details']; ?>
</td>
<td class = "left">
<?php echo $selectedcontactus['Replyconf']; ?>
</td>
</tr>
<?php
} // End of else
$dbc = null;
?>
</table>
<?php
echo("<p><a href='contact.html'>Proceed</a></p>");
?>
</body>
</html>

