<!DOCTYPE html>
<html>
<head>
    <title> List of all the mobile devices </title>
    <meta charset="utf-8" />
    <link href="phoneandtabletDevices.css" type="text/css" rel="stylesheet" />
</head>
<body>
<?php
$refNo = $_POST['refNo'];
$dsn =
 'mysql:host=laureatestudentserver.com;dbname=laureate_IN169';
 $dbname="laureate_IN169";
 $username = "laureate_IN169";
 $password = "tUv5EKnV9KaK";
 $conn = new mysqli($username, $password, $dbname);
 if(isset($_POST['del']))
        {
          $sqli=" DELETE FROM uzoorangedevices WHERE refNo = '$refNo'";
          $result=mysqli_query($con, $sqli);
}
?>
</body>
</html>
