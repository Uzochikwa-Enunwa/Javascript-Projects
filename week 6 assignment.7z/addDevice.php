<!DOCTYPE html>
<html>
<head>
    <title> List of all the mobile devices </title>
    <meta charset="utf-8" />
    <link href="phoneandtabletDevices.css" type="text/css" rel="stylesheet" />
</head>
<body>
<?php
 if ( ! empty( $_POST ) ) {
 //Connecting to the database
 $mysqli = new mysqli( 'laureatestudentserver.com', 'laureate_IN169', 'tUv5EKnV9KaK', 'laureate_IN169' );
 //To check if it is connected or not
if ( $mysqli->connect_error ) {
    die( 'Connect Error: ' . $mysqli->connect_errno . ': ' . $mysqli->connect_error );
  }
 //After which we insert values into the database
//Then we will run the add or insert query.
 $sql = "INSERT INTO uzoorangedevices ( refNo, name, DeviceType, Colour, StockLevel, SalesThisMonth, CustomerRating(1-5) ) VALUES ( '{$mysqli->real_escape_string($_POST['Reference'])}', '{$mysqli->real_escape_string($_POST['addingname'])}', '{$mysqli->real_escape_string($_POST['addingdevice'])}', '{$mysqli->real_escape_string($_POST['addingcolour'])}', '{$mysqli->real_escape_string($_POST['addingstocklevel'])}', '{$mysqli->real_escape_string($_POST['addingsales'])}', '{$mysqli->real_escape_string($_POST['addingcustomer'])}')";
  $insert = $mysqli->query($sql);
  // Print response from MySQL
  if ( $insert ) {
    echo "Success! Row ID: {$mysqli->insert_id}";
  } else {
    die("Error: {$mysqli->errno} : {$mysqli->error}");
  }
  // Connection will then be closed
  $mysqli->close();
}
?>
</body>
</html>
