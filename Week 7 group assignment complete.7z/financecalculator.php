<html>
<head>
    <title> List of all the mobile devices </title>
    <meta charset="utf-8" />
    <link href="ora_css.css" type="text/css" rel="stylesheet" />
</head>
<body>
<?php
 if ( ! empty( $_POST ) ) {
 //Connecting to the database
 $mysqli = new mysqli( 'laureatestudentserver.com', 'laureate_IN169', 'tUv5EKnV9KaK', 'laureate_IN169' );
 //To check if it is connected or not
if ( $mysqli->connect_error ) {
    die( 'Connect Error: ' . $mysqli->connect_errno . ': ' . $mysqli->connect_error );
  }
  $ItemsOwned=implode(',', $_POST['ItemsOwned']);
 //After which we insert values into the database
//Then we will run the add or insert query.
$sql = "INSERT INTO uzoorangeorabanks ( AcctNo, Name, DofB, Address, Email, Sex, MartialStatus, Documents, ProofofIdent ) VALUES ( '{$mysqli->real_escape_string($_POST['Financeacct'])}', '{$mysqli->real_escape_string($_POST['Financename'])}', '{$mysqli->real_escape_string($_POST['Financebirth'])}', '{$mysqli->real_escape_string($_POST['Financeaddress'])}', '{$mysqli->real_escape_string($_POST['Financemail'])}', '{$mysqli->real_escape_string($_POST['Financesex'])}', '{$mysqli->real_escape_string($_POST['Financemarital'])}', '{$mysqli->real_escape_string($ItemsOwned)}', '{$mysqli->real_escape_string($_POST['changingidentification'])}')";
  $insert = $mysqli->query($sql);
  // Print response from MySQL
  if ( $insert ) {
    echo "Success,Information on your application form has been submitted! Row ID: {$mysqli->insert_id}";
    echo("<p><a href='Uzo_orangegroup_pfinance.php'>Proceed</a></p>");
  } else {
    die("Error: {$mysqli->errno} : {$mysqli->error}");
  }
  // Connection will then be closed
  $mysqli->close();
}
?>
</body>
</html>

