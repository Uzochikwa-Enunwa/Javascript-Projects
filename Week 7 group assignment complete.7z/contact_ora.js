/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function validatecontactForm(){
    valid = true;

        if ( (document.contentValidate.IO4.checked=== false) && ( document.contentValidate.IO5.checked === false) && ( document.contentValidate.IO6.checked === false) && ( document.contentValidate.IO7.checked === false) && ( document.contentValidate.IO8.checked === false) )
        {
                alert ( "Please check a feedback checkbox." );
                valid = false;
        }

        if ( document.contentValidate.feedbackproblem.value === "" )
        {
                alert ( "please fill in the feedback details textbox" );
                valid = false;
        }

        if ( ( document.contentValidate.FQ1.checked === false ) && ( document.contentValidate.FQ2.checked === false ) )
        {
                alert ( "Please choose a yes or no option" );
                valid = false;
        }
        if ( document.contentValidate.fullcontactname.value === "" )
        {
                alert ( "please fill in the contact name textbox" );
                valid = false;
        }
        if ( document.contentValidate.fullemail.value === "" )
        {
                alert ( "please fill in the E-mail textbox" );
                valid = false;
        }
        if ( document.contentValidate.fullaccountnumber.value === "" )
        {
                alert ( "please fill in the Account Number textbox" );
                valid = false;
        }
        return valid;
}
    function myFunction() {
      if (document.getElementById("edit-what-was-the-problem").value===""){
          document.getElementById("edit-what-was-the-problem").style.backgroundColor="orange";
      }
  }
  function querycontactForm(){
    valid = true;
    if ( document.contactValidate.AcctNumber.value === "" )
        {
                alert ( "please fill in the Account Number query details textbox" );
                valid = false;
        }
        return valid;
    }
  function validatepersonal_financeForm() {
      valid = true;
      
      if ( (document.financeValidate.IO1.checked=== false) && ( document.financeValidate.IO2.checked === false) && ( document.financeValidate.IO3.checked === false) )
        {
                alert ( "Please check a checkbox." );
                valid = false;
        }

        if ( document.financeValidate.changingidentification.value === "" )
        {
                alert ( "please fill in the identification textbox" );
                valid = false;
        }
         if ( document.financeValidate.Financeacct.value === "" )
        {
                alert ( "please fill in the 10 Digit Account number textbox" );
                valid = false;
        }
         if ( document.financeValidate.Financename.value === "" )
        {
                alert ( "please fill in the name textbox" );
                valid = false;
        }
         if ( document.financeValidate.Financebirth.value === "" )
        {
                alert ( "please fill in the Date of Birth textbox" );
                valid = false;
        }
         if ( document.financeValidate.Financeaddress.value === "" )
        {
                alert ( "please fill in the Address textbox" );
                valid = false;
        }
         if ( document.financeValidate.Financemail.value === "" )
        {
                alert ( "please fill in the email textbox" );
                valid = false;
        }
         if ( document.financeValidate.Financesex.value === "" )
        {
                alert ( "please fill in the sex textbox" );
                valid = false;
        }
        if ( document.financeValidate.Financemarital.value === "" )
        {
                alert ( "please fill in the Marital status textbox" );
                valid = false;
        }

        return valid;
}
    function FinanceFunction() {
    if (document.getElementById("changingidentification").value===""){
          document.getElementById("changingidentification").style.backgroundColor="silver";
      }
  }
   function validatefinance_calculator() {
      valid = true;
      if ( document.calculatorValidate.changingname.value === "" )
        {
                alert ( "please fill in the name textbox" );
                valid = false;
        }
        if ( document.calculatorValidate.changingdate.value === "" )
        {
                alert ( "please fill in the date textbox" );
                valid = false;
        }
        if ( document.calculatorValidate.changingAmount.value === "" )
        {
                alert ( "please fill in the Loan Amount textbox" );
                valid = false;
        }
        if ( document.calculatorValidate.changingInterest.value === "" )
        {
                alert ( "please fill in the Interest rate textbox" );
                valid = false;
        }
         
    return valid;
}
    function FinanceCalculator() {
      if (document.getElementById("payment").value===""){
          document.getElementById("payment").style.backgroundColor="pink";
      }
  }
    function showinterestrate() {
 if ((document.calculatorValidate.changingAmount.value === null || document.calculatorValidate.changingAmount.value.length === 0) ||
     (document.calculatorValidate.changingyears.value === null || document.calculatorValidate.changingyears.value.length === 0)
||
     (document.calculatorValidate.changingInterest.value === null || document.calculatorValidate.changingInterest.value.length === 0))
 { document.calculatorValidate.payment.value = "Incomplete data";
 }
 else
 {
 var princ = document.calculatorValidate.changingAmount.value;
 var term  = document.calculatorValidate.changingyears.value;
 var intr   = document.calculatorValidate.changingInterest.value / 1200;
 document.calculatorValidate.payment.value = princ * intr / (1 - (Math.pow(1/(1 + intr), term)));
 }

// payment = principle * monthly interest/(1 - (1/(1+MonthlyInterest)*Months))

}
