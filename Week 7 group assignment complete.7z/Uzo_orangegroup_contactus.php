<!DOCTYPE html>
<html>
<head>
<title> List of all the mobile devices </title>
<meta charset="utf-8" />
<link href="ora_css.css" type="text/css" rel="stylesheet" />
</head>
<body>
    <p>
<h2> Customers Feedback Information</h2>
</p>
<?php
 $dsn ='mysql:host=laureatestudentserver.com;dbname=laureate_IN169';
 $username = 'laureate_IN169';
 $password = 'tUv5EKnV9KaK';
 $dbc = new PDO($dsn, $username, $password);
 $query = 'SELECT * FROM uzoorangeoracontactus ORDER BY AcctNumber';
 $results = $dbc->query($query);
 $rows = $results->rowCount();
 ?>
<table>
<caption>Contact Us feedback Database</caption>
<thead>
<tr>
<th>AcctNumber</th>
<th>fullName</th>
<th>Email</th>
<th>Feedback</th>
<th>Details</th>
<th>Replyconf</th>
</tr>
</thead>
<?php
if ($rows == 0)
{
echo("<p> There are no values returned</p>");
echo("<p><a href='contact.html'>You may Proceed</a></p>");
}
else {
foreach ($results as $selectedcontactus) :
    ?>
<tr>
<td class = "left">
<?php echo $selectedcontactus['AcctNumber']; ?>
</td>
<td class = "left">
<?php echo $selectedcontactus['fullName']; ?>
</td>
<td class = "left">
<?php echo $selectedcontactus['Email']; ?>
</td>
<td class = "left">
<?php echo $selectedcontactus['Feedback']; ?>
</td>
<td class = "left">
<?php echo $selectedcontactus['Details']; ?>
</td>
<td class = "left">
<?php echo $selectedcontactus['Replyconf']; ?>
</td>
</tr>
<?php endforeach;
echo("<p><a href='contact.html'>Proceed</a></p>");
}
$dbc = null;
?>
</table>
</body>
</html>

