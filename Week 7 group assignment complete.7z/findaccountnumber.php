<!DOCTYPE html>
<html>
<head>
<title> Searching for a Single Record </title>
<meta charset="utf-8" />
<link href="ora_css.css" type="text/css" rel="stylesheet" />
</head>
<body>

<p>
<h2>Personal Finance Customer Information Search Result</h2>
<?php
$AcctNo = $_POST['AcctNo']; 
$dsn = 'mysql:host=laureatestudentserver.com;dbname=laureate_IN169';
$username = 'laureate_IN169';
$password = 'tUv5EKnV9KaK';
$dbc = new PDO($dsn, $username, $password);
$query = "SELECT * FROM uzoorangeorabanks WHERE AcctNo ='" . $AcctNo . "'";
/* The SQL says "Select everything from the uzoorangeorabanks table where the account number equals that which the user typed into the previous HTML form. As the AcctNo is unique, there will be at most one record */
$results = $dbc->query($query); 
$rows = $results->rowCount(); ?>  
<?php 
if ($rows == 0) {
      echo("<p> There is no information to show because the account does not exist");
}
else {
$selectedFinanceInfo = $results->fetch();
/* Fetch a record from the $results variable and store it in $selectedFinanceInfo. There will be a maximum of one record */      
?>
<table border>
<caption>Personal finance customer Query </caption>
<thead>
<tr>
<th>AcctNo</th>
<th>Name</th>
<th>DofB</th>
<th>Address</th>
<th>Email</th>
<th>Sex</th>
<th>MartialStatus</th>
<th>Documents</th>
<th>ProofofIdent</th>
</tr>
</thead> 
<tr>
<td class = "left">
<?php echo $selectedFinanceInfo['AcctNo']; ?>
</td>
<td class = "left">
<?php echo $selectedFinanceInfo['Name']; ?>
</td>
<td class = "left">
<?php echo $selectedFinanceInfo['DofB']; ?>
</td>
<td class = "left">
<?php echo $selectedFinanceInfo['Address']; ?>
</td>
<td class = "left">
<?php echo $selectedFinanceInfo['Email']; ?>
</td>
<td class = "left">
<?php echo $selectedFinanceInfo['Sex']; ?>
</td>
<td class = "left">
<?php echo $selectedFinanceInfo['MartialStatus']; ?>
</td>
<td class = "left">
<?php echo $selectedFinanceInfo['Documents']; ?>
</td>
<td class = "left">
<?php echo $selectedFinanceInfo['ProofofIdent']; ?>
</td>
</tr>
<?php
} // End of else
$dbc = null;
?>
</table>
<?php
echo("<p><a href='personal_finance.html'>Proceed</a></p>");
?>
</body>
</html>

